package com.upload;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.DBUTIL.MyDbConnection;

/**
 * Servlet implementation class ServUpload
 */
public class ServUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Connection con;
		Statement st;
		
		String baseline;
		String na=request.getParameter("tt");
		String path="C:/Users/admin/workspace/dsd/WebContent/doc";
		out.print("My baseline: "+na);
		
		File file;
		int maxsize=50000*2;
		int maxfactsize=50000*2;
		String contentType=request.getContentType();
		out.println(contentType);
		if(contentType.indexOf("multipart/form-data")>=0){
			out.println("its valid");
			DiskFileItemFactory disfct=new DiskFileItemFactory();
			disfct.setSizeThreshold(maxfactsize);
			disfct.setRepository(new File("E:\\demo"));
			ServletFileUpload  upload=new ServletFileUpload(disfct);
			upload.setSizeMax(maxsize);
			try {
				List lis=upload.parseRequest(request);
				Iterator ii=lis.iterator();
				while(ii.hasNext()){
					FileItem item=(FileItem)ii.next();
					
					//out.println(item.isFormField());
					if(!item.isFormField()){
						baseline=item.getName();
						baseline="vivek"+baseline.substring(baseline.indexOf("."));
						out.println(baseline);
						file=new File(path,baseline);
						item.write(file);
						out.println("File uploaded success");
						String io="yogesh";
						String query="insert into prof values('"+io+"','"+baseline+"')";
						con=MyDbConnection.obtainConnection();
						st=con.createStatement();
						st.executeUpdate(query);
						out.println("file added to database");
						
						
						out.println("\n");

						out.println("\n");
						out.println("\n");
						out.println("\n");
						out.println("<center>click here---> <a href='http://localhost:8095/dsd/view.jsp'>view files</a>");
						
					}
				
				}
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else{
			out.println("not valid format.");
		}
	}


}
