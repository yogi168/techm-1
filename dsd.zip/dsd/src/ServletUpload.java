

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javazoom.upload.MultipartFormDataRequest;
import javazoom.upload.UploadBean;
import javazoom.upload.UploadFile;

public class ServletUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try
        {
      res.setContentType("text/html");
      PrintWriter out = res.getWriter();

      UploadBean ub =new UploadBean();
      ub.setFolderstore("F:/");
      ub.setOverwrite(false);

      MultipartFormDataRequest mpfr =new MultipartFormDataRequest(req);
      ub.store(mpfr); //store the uploaded file to destination

      Hashtable ht = mpfr.getFiles();
      Enumeration ee =ht.elements();

      while(ee.hasMoreElements())
              {
   
              UploadFile f =(UploadFile)ee.nextElement();
              out.println(f.getFileName());
              }

         }catch(Exception  e)
              {
             e.printStackTrace();
              }
	}

}
