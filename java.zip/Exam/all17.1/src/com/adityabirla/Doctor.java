package com.adityabirla;

import java.util.ArrayList;
import java.util.Iterator;

public class Doctor {

	private String docId;
	private String docName;
	private ArrayList<Appointment> appList = new ArrayList<Appointment>();

	public void addAppointment(Appointment ap) {
		appList.add(ap);
	}

	public void printAppointment() {
		Iterator<Appointment> itr = appList.iterator();
		while (itr.hasNext()) {
			Appointment ap = (Appointment) itr.next();
			System.out.println("Appointment date: " + ap.getAppDate());
			System.out.println("No of patients: " + ap.getNoOfPatients());
		}
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

}
