package com.adityabirla;

public class InvalidDataException extends Exception {
	private static final long serialVersionUID = 1L;

	InvalidDataException(String s) {
		super(s);
	}
}
