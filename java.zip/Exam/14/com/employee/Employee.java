package com.employee;

public class Employee {
	int empNo;
	float basicPay, hra, conveyance, epf, tax;
	

}
