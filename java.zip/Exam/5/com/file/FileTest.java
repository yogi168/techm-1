package com.file;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileTest {
	public static void main(String[] args) throws IOException{
		File f=new File("Test");
		File f1=new File("Source.txt");
		File f2=new File("Destination.txt");
		System.out.println(f.mkdir());
		System.out.println(f1.createNewFile());
		System.out.println(f2.createNewFile());
FileReader fr=new FileReader("Source.txt");
FileWriter fw=new FileWriter("Destination.txt");

}
}