package com.emp;

public class Technical extends Employee{
	
	String jobDesc;	 
	String 	grade;	
	
	public Technical(int empId, String empName, String date, double basicSal,
			String jobDesc, String grade) {
		super(empId, empName, date, basicSal);
		this.jobDesc = jobDesc;
		this.grade = grade;
		this.bonus = bonus;
		this.income = income;
	}
	public void showDetails() {
		System.out.println(empId+"is..."+empName+"is..."+date+".."+jobDesc+"...."+grade);
	}
	
	int bonus;
	int income;
	public void calcSal(){
		bonus=(int) (basicSal*0.1);
		income=(int) (basicSal+bonus);
		System.out.println("income is"+income);
	}
}
