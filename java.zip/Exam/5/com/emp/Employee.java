package com.emp;

public abstract class Employee {
	int empId;	        	   	           
	String empName;	        	
 	String date;
	double basicSal;
	public Employee(int empId, String empName, String date,
			double basicSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.date=date;
		this.basicSal = basicSal;
	}
public void	showDetails(){
	System.out.println(empId+"is..."+empName+"is..."+date+".."+basicSal);
}
protected abstract void calcSal();

}
