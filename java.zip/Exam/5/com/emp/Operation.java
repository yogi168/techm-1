package com.emp;

public class Operation extends Employee {
	public Operation(int empId, String empName, String dateOfJoining,
			double basicSal) {
		super(empId, empName, dateOfJoining, basicSal);
	}
	String jobDesc;	 
	String 	grade;	
public void showDetails() {
	System.out.println(jobDesc+"is..."+grade+"is...");
		}
public int sal;
int bonus;
int income;
public void calcSal(){
	bonus=(int) (sal*0.05);
	income=sal+bonus;
}
}
