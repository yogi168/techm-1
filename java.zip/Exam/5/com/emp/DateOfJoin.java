package com.emp;

public class DateOfJoin {
int	day;
int month;
int year;
String date;

public DateOfJoin(int day, int month, int year) {
	super();
	this.day = day;
	this.month = month;
	this.year = year;
}
public String showDate() {
	System.out.println(day+"/" +month +"/"+year);
	 date=day+"/" +month +"/"+year;
	return date;
}
}
