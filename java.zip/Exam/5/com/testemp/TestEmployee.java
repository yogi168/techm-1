package com.testemp;
import com.emp.*;
import java.util.Scanner;

import com.emp.DateOfJoin;
import com.emp.Employee;
import com.emp.Operation;
import com.emp.Technical;

public class TestEmployee {
public static void main(String[] args){
	DateOfJoin dateOfJoining =new DateOfJoin(30,10,2016);
	Employee[] e = new Employee[2];
	
	Scanner sc= new Scanner(System.in);
	
	System.out.println("enter jobdesc of technical employee");
	String Technical=sc.next();
	System.out.println("enter grade");
	String g=sc.next();
	/*public Technical(int empId, String empName, String date, double basicSal,
			String jobDesc, String grade) */
String date = dateOfJoining.showDate();
	System.out.println(dateOfJoining.showDate());
	e[0]=new Technical(01,"uni",date,20000,Technical,g);

	
	e[0].showDetails();
	Operation o;
	o=(Operation) e[1];
	System.out.println("enter jobdesc of operational employee");
	String Operation=sc.next();
	System.out.println("enter grade of operational employee");
	String O=sc.next();
	dateOfJoining.showDate();
	
	sc.close();
	
}
}
