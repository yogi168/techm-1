package com.bill;

public class RegularCustomer extends Customer {
	float billAmount;
	public int custId;
	public String custName;
	public long mobileNumber;
	public int billNo;
	public float d;

	public int getBillNo() {
		return billNo;
	}

	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}

	public float getBillAmount(float billAmount) {
		return billAmount;
	}

	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}

	public RegularCustomer(int custId, String custName, long mobileNumber,
			int billNo, float d) {
		super(custId, custName, mobileNumber);
		this.billNo = billNo;
		this.billAmount = d;
	}

	public double calculateBillAmount(int minutes) {

		if (minutes <= 30) {
			billAmount = (float) (minutes * 1.5);
			System.out.println("bill amt is 1.5 rupee per minute");
		} else {
			System.out.println("bill amt is 1 rupee per minute");
			billAmount = 30 * 1;
			billAmount = (float) (billAmount + (minutes - 30) * 1);
		}
		return billAmount;
	}

}
