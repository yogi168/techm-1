package com.bill;

public abstract class Customer {
	public double BillAmount = 0;
	public int custId;
	public String custName;
	public long mobileNumber;
	public int billNo;

	public double getBillAmount() {
		return BillAmount;
	}

	public void setBillAmount(double billAmount) {
		BillAmount = billAmount;
	}

	public int getBillNo() {
		return billNo;
	}

	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}

	public double calculateBillAmount(int minutes) {

		return BillAmount;
	}

	public Customer(int custId, String custName, long mobileNumber) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.mobileNumber = mobileNumber;
	}

	public String toString() {
		return custId + "..." + custName + "..." + mobileNumber;
	}

	public int getCustId() {
		return custId;
	}

	public int setCustId(int custId) {
		return this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}
