package com.bill;

public class PremiumCustomer extends Customer {
	public PremiumCustomer(int custId1, String custName1, long mobileNumber1,
			int billNo1, int minutes1) {
		super(custId1, custName1, mobileNumber1);

	}

	int billNo;
	float billAmount;

	public int getBillNo() {
		return billNo;
	}

	public void setBillNo() {
		this.billNo = billNo;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}

	public double calculateBillAmount(int minutes1) {
		// For first 30 mins, it is Rs 1 / minute. Then after it is 0.50
		// paise/minute
		if (minutes1 <= 30) {
			billAmount = minutes1 * 1;
			System.out.println("bill amt is 1 rupee per minute");
		} else {
			billAmount = minutes1 * 1;
			billAmount = (float) (billAmount + (minutes1 - 30) * 1);
		}
		return billAmount;
	}

}
