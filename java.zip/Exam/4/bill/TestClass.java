package com.bill;

import java.util.Scanner;

public class TestClass {
	private static int custId;

	public static void main(String[] args) {
		Customer c[] = new Customer[2];
		
		Scanner sc = new Scanner(System.in);
		System.out.println(" customer id is");
		int customerId = sc.nextInt();
		int customerId1 = sc.nextInt();
		System.out.println("enter customername");
		String customerName = sc.next();
		String customerName1 = sc.next();
		System.out.println("enter mobile no");
		int mobileNumber = sc.nextInt();
		int mobileNumber1 = sc.nextInt();
		System.out.println(" billno is");
		int billNo = sc.nextInt();
		int billNo1 = sc.nextInt();
		System.out.println("enter minutes");
		int minutes = sc.nextInt();
		int minutes1 = sc.nextInt();
		
		System.out.println(c[0].calculateBillAmount(minutes));
		 System.out.println(c[1].calculateBillAmount(minutes1));
		 int billAmount = 0;
		c[0] = new RegularCustomer(custId,customerName, mobileNumber,billAmount, minutes);
			System.out.println(c[0]);
			 c[1]=new PremiumCustomer(c[1].getCustId(), customerName1,mobileNumber1,c[1].getBillNo(),minutes1);
			 System.out.println(c[1]);
			
		float total = (float)((c[0].calculateBillAmount(minutes))+(c[1].calculateBillAmount(minutes1)));
		System.out.println(total);
		sc.close();
	}

}

