import java.util.Iterator;

public class SecondThread extends Thread {

	FirstThread firstthread;

	Item item = new Item();

	public SecondThread(FirstThread firstthread) {
		this.firstthread = firstthread;

	}

	public void run() {
		synchronized (firstthread) {

			Iterator<Item> itr = firstthread.al.iterator();
			while (itr.hasNext()) {
				item.printItemDetails((Item) itr.next());
			}
		}

	}

}
