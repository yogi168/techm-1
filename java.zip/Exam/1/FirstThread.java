import java.util.ArrayList;
import java.util.Scanner;

public class FirstThread extends Thread {
	ArrayList<Item> al = new ArrayList<>();

	public void run() {
		synchronized (this) {

			for (int limit = 1; limit <= 5; limit++) {
				//item entries
				System.out.print("Please enter ID of item number " + limit
						+ " :\n");
				int itemIdFromUser = Math.round((int) Math.random()) + 10;
				Scanner sc = new Scanner(System.in);

				System.out.print("Please enter Name of item number " + limit
						+ " :\n");
				String itemNameFromUser = sc.next();

				Item item = new Item(itemIdFromUser, itemNameFromUser);

				al.add(item);

				this.notify();

			}

		}

	}

}
