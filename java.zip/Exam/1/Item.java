public class Item {
	int itemId;
	String itemName;

	public Item(int itemId, String itemName) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	// Created a default constructor
	public Item() {

	}

	// Created a method to print all the item details
	public void printItemDetails(Item item) {

		System.out.println("------------------------------------");
		System.out.println("The Item Id is: " + item.itemId);
		System.out.println("The Item Name is: " + item.itemName);
		System.out.println("------------------------------------");

	}

	public static void main(String[] args) {

		// Creating the first thread
		FirstThread firstthread = new FirstThread();

		// Creating second thread
		SecondThread secondthread = new SecondThread(firstthread);

		// Starting first thread to create Item objects
		firstthread.start();

		// Starting second thread to display Item objects' properties
		secondthread.start();

	}

}
