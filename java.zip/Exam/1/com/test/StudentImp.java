package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.student.Student;

public class StudentImp {
	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		File f = new File("StudentInfo.txt");
		File f1 = new File("info");
		// System.out.println(f1.mkdir()); to create folder
		// System.out.println(f.createNewFile()); to create file
		Student s1 = new Student();
		s1.readStudInfo();
		s1.calcTotal();

		FileOutputStream fileoutput = new FileOutputStream(f);// to read input into file
		ObjectOutputStream op = new ObjectOutputStream(fileoutput);// using object send
		op.writeObject(s1);
		op.close();
		FileInputStream fileinput = new FileInputStream(f);// to read input into file
		ObjectInputStream ip = new ObjectInputStream(fileinput);
		Student s2 = (Student) ip.readObject();
		ip.close();
		s2.printStudInfo();
		
	}
}
