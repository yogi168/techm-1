package com.student;

import java.io.Serializable;
import java.util.Scanner;

@SuppressWarnings("serial")
public class Student implements StudentInt, Serializable {

	private int rollNo;
	private String name;
	private int subject1;
	private int subject2;
	private int subject3;
	private int totalMarks;

	// Getters and Setters - to access the private variables in another class

	

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSubject1() {
		return subject1;
	}

	public void setSubject1(int subject1) {
		this.subject1 = subject1;
	}

	public int getSubject2() {
		return subject2;
	}

	public void setSubject2(int subject2) {
		this.subject2 = subject2;
	}

	public int getSubject3() {
		return subject3;
	}

	public void setSubject3(int subject3) {
		this.subject3 = subject3;
	}

	@Override
	public void readStudInfo() {

		// Reading values from the user

		Scanner s = new Scanner(System.in);

		System.out.println("Please enter your Roll Number : ");
		int rollNo = s.nextInt();

		System.out.println("Please enter your Name : ");
		String name = s.next();

		System.out.println("Please enter your Subject1 marks : ");
		int subject1 = s.nextInt();

		System.out.println("Please enter your Subject2 marks : ");
		int subject2 = s.nextInt();

		System.out.println("Please enter your Subject3 marks : ");
		int subject3 = s.nextInt();

		// Accessing the private variables
		setRollNo(rollNo);
		setName(name);
		setSubject1(subject1);
		setSubject2(subject2);
		setSubject3(subject3);
	}

	
	//Overriden the Interface Method to calculate the Total Marks
	@Override
	public void calcTotal() {

		totalMarks = subject1 + subject2 + subject3;
		System.out.println("Dear " + name + ", your total marks are : "
				+ totalMarks);
	//return totalMarks;	
	}

	//Overriden the Interface Method to print the Student Details
	@Override
	public void printStudInfo() {
		System.out.println("---------------------------------------");
		System.out.println("Student Roll Number is : " + rollNo);
		System.out.println("Student NAME is : " + name);
		System.out.println("Student's Subject1 marks are : " + subject1);
		System.out.println("Student's Subject2 marks are: " + subject2);
		System.out.println("Student's Subject3 marks are: " + subject3);
		calcTotal();
		System.out.println("---------------------------------------");
	}

}