package com.student;

public interface StudentInt {
	abstract void readStudInfo();

	abstract void calcTotal();

	abstract void printStudInfo();

}
