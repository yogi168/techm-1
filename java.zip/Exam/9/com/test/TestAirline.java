package com.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.airline.International;

public class TestAirline {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
		System.out.println("enter airid");
		String id=br.readLine();
		System.out.println("enter source");
		String source = br.readLine();
		System.out.println("enter destination");
		String destination=br.readLine();
		System.out.println("enter zonalcode");
		String zcode=br.readLine();
		//Domestic d = new Domestic(id,source,destination,zcode);
		International i = new International(id,source,destination,zcode);
		i.bookTicket(5);

	}

}
