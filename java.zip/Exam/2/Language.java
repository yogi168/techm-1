public interface Language {

	void showMessage();

}
