package com.vehicle;

public abstract class Vehicle {
	protected static int vehicleNo;	         
	protected static String engineStatus	;
	protected static int currentGear	;
	
	
	public Vehicle(int vehicleNo, String engineStatus, int currentGear) {
		super();
		this.vehicleNo = vehicleNo;
		this.engineStatus = engineStatus;
		this.currentGear = currentGear;	
	}
	
	public static void setVehicleNo(int vehicleNo) {
		Vehicle.vehicleNo = vehicleNo;
	}

	public abstract void ignite();//abstract methods don't have body
	public abstract int changeGear(int flag);
	public abstract void stop();	
	}


