package com.vehicle.test;

import java.util.Scanner;

import com.vehicle.Car;
import com.vehicle.Vehicle;

public class TestVehicle {
public static  void main(String[] args){

	boolean power=true;
	String fuel="gas";
	Vehicle v=new Car(power,  fuel);
	int vehicleNo=Math.round((int) Math.random())+10;
	Vehicle.setVehicleNo(vehicleNo);
	v.ignite();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter flag value:");
	int flag=sc.nextInt();
	v.changeGear(flag);
	v.stop();
	sc.close();
	Car c =(Car) v;
	c.showCarDetails();
}
}
