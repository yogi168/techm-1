package com.vehicle;

public class Car extends Vehicle {
	Boolean powerStearing=true;
 String fuelType="gas";
	
	public Car(Boolean powerStearing, String fuelType) {
		super(vehicleNo, engineStatus, currentGear);
		this.powerStearing = powerStearing;
		this.fuelType = fuelType;
	}
public 	void ignite()
	{
		engineStatus="on";
		currentGear=1;
		System.out.println("engineStatus.."+engineStatus+"currentGear.."+currentGear);
	}
	public  int changeGear(int flag){
		
		 if(flag==1&& currentGear<6)
		 {
			 currentGear++;
		 }
		 else if(flag==-1&&currentGear>1)
		 {
			 currentGear--;
		 }
		 else
		   {
			   System.out.println("invalid flag value"); 
		   }
		 System.out.println("current gear is.."+currentGear);
		 return flag;
	 }
	public  void stop(){
		 engineStatus="off";
			currentGear=0;
			 System.out.println("engine status is.."+engineStatus);
	}
public 	 void showCarDetails( ) {

 	System.out.println("the vehicle number is.."+super.vehicleNo);
 	System.out.println("engine status is.."+super.engineStatus);
 	System.out.println("current gear is.."+super.currentGear);
 	System.out.println("power steering is.."+powerStearing);
 	//String fuelType="gas";
    System.out.println("fuel type is..."+fuelType);
 	


}
}
