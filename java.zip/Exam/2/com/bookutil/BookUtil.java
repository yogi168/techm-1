package com.bookutil;

import com.book.Book;
import com.book.BookStore;

import java.util.ArrayList;
import java.util.Scanner;

public class BookUtil {
	// Start of main method
	public static void main(String[] args) {
		BookStore s = new BookStore();
		Scanner sc = new Scanner(System.in);
		ArrayList al = new ArrayList();
		Book b[] = new Book[3];
		for (int i = 0; i <= 1; i++) {
			System.out.println("enter details of book" + (i));
			System.out.println("enter bookId");
			String bookId = sc.next();
			System.out.println("enter book title");
			String title = sc.next();
			System.out.println("enter book author");
			String author = sc.next();
			System.out.println("enter book category");
			String category = sc.next();
			System.out.println("enter book price");
			float price = sc.nextFloat();
			b[i] = new Book(bookId, title, author, category, price);
			// to add new book objects
			s.addBook(b[i]);
			System.out.println("enter author to search");
			String author1 = sc.next();
			s.searchByAuthor(author1);
			System.out.println("enter Title to search");
			String Title1 = sc.next();
			s.searchByTitle(Title1);
			s.displayAll();

		}

	}
}
