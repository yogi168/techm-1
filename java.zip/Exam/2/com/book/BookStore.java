package com.book;

import java.util.ArrayList;
import java.util.Iterator;

public class BookStore {
	ArrayList al = new ArrayList();
	Iterator i = al.iterator();

	public void addBook(Book b) {
		al.add(b);
	}

	// Method to Search by Title
	public void searchByTitle(String title) {
		Iterator i = al.iterator();
		while (i.hasNext()) {
			Book b = (Book) i.next();
			if (b.getTitle().equalsIgnoreCase(title)) {
				System.out.println("The book details are.....");
				System.out.println(b);
			} else
				System.out.println("not found");
		}

	}

	// Method to search by author
	public void searchByAuthor(String author) {
		Iterator i = al.iterator();
		while (i.hasNext()) {
			Book b = (Book) i.next();
			if (b.getAuthor().equalsIgnoreCase(author)) {
				System.out.println("The book details are.....");
				System.out.println(b);
			} else
				System.out.println("not found");
		}

	}

	// To display the details
	public void displayAll() {
		Iterator i = al.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}

	}

}