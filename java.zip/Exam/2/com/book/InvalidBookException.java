package com.book;

//Exception class
public class InvalidBookException extends RuntimeException {
	InvalidBookException(String name) {
		super(name);
	}

}
