package com.Employee;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import javax.activity.InvalidActivityException;
public class TestFile {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of employees:");
		int n = sc.nextInt();

		int arraySize = n;
		Employee emp[] = new Employee[n];
		for (int count = 0; count < n; count++) {
			System.out.println("enter employee id:");
			int empId = sc.nextInt();
			System.out.println("enter employee name:");
			String empName = sc.next();
			System.out.println("enter employee grade:");
			String grade = sc.next();
			Employee emp1 = new Employee(empId, empName, grade);
			int x = 0;
			try {
				
				x = emp1.validate(grade);
				if (x == 1) {
					emp[arraySize] = emp1;
					arraySize++;
				}

			} 
			catch (Exception e) {
				System.out.println(e);
			}
		}

		System.out.println("The number correct entered records are" + arraySize);
	
		FileOutputStream fos = new FileOutputStream("empdetails.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		for (int i = 0; i < arraySize; i++) {
			oos.writeObject(emp[i]);
		}
		FileInputStream fis = new FileInputStream("empdetails.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		for (int i = 0; i <= arraySize; i++) {
			Employee emp2 = (Employee) ois.readObject();
			System.out.println("the emp details are.." + emp2);
		}

	}

}


/*class InvalidGradeException extends RuntimeException {
	InvalidGradeException(String name) {
		super(name);
	}
}

public class TestFile {
	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter grade value");
		String grade = sc.next();
		if (!(grade.equals("U1") || grade.equals("U2") || grade.equals("U3")
				|| grade.equals("U4") || grade.equals("P1") || grade
					.equals("P2"))) {
			try {
				if (!(grade.equals("U1") || grade.equals("U2")
						|| grade.equals("U3") || grade.equals("U4")
						|| grade.equals("P1") || grade.equals("P2"))) {
					throw new InvalidGradeException("Invalid input");
				}
			}

			catch (Exception e1) {

			}

		}

		else {
			System.out.println("Enter n value");
			int n = sc.nextInt();
			Employee[] e = new Employee[n];

			for (int i = 0; i < e.length; i++) {
				System.out.println("enter empid");
				int empId = sc.nextInt();
				System.out.println("enter ename");
				String empName = sc.next();
				e[i] = new Employee(empId, empName, grade);

			}
			File f = new File("empdetails.txt");
			File f1 = new File("info");
			FileOutputStream fo = new FileOutputStream(f);// to read input into
															// file
			ObjectOutputStream op = new ObjectOutputStream(fo);// using object
			for (int i = 0; i < n; i++) { // send
				op.writeObject(e[i]);
			}
			op.close();
			FileInputStream fi = new FileInputStream(f);// to read input into
														// file
			ObjectInputStream ip = new ObjectInputStream(fi);
			Employee e2 = (Employee) ip.readObject();

			ip.close();
			for (int i = 0; i < n; i++) {
				System.out.println(e[i]);
			}
		}
	}
}*/
