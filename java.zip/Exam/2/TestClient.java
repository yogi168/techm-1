import java.util.Scanner;

public class TestClient {
	//Start of main method
	public static void main(String[] args) {
		CLang c = new CLang();
		JavaLang j = new JavaLang();
		Thread t1 = new Thread(c);
		Thread t2 = new Thread(j);
		System.out.println("Select your favourite language");
		Scanner sc = new Scanner(System.in);
		String S = sc.next();

		switch (S) {
		case "c":
			t1.setPriority(5);
			break;
		case "j":
			t2.setPriority(10);
			break;
		default:
			System.out.println("choice is incorrect");
			break;
		}
		
		if (S.equals("j") || S.equals("c")) {
		
			t1.start();
			t2.start();
		}

	}
}
