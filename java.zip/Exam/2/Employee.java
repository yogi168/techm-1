package com.Employee;

import java.io.Serializable;

public class Employee implements Serializable{
	int empId;
	String empName;
	String grade;

	

	public Employee(int empId, String empName, String grade) {
		// TODO Auto-generated constructor stub
		this.empId = empId;
		this.empName = empName;
		this.grade = grade;
	}

	
	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}



	public int validate(String grade2) {
		// TODO Auto-generated method stub
		return 0;
	}
}
