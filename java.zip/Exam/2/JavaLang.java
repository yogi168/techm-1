public class JavaLang implements Language, Runnable {
	public void run() {
		showMessage();
	}

	public void showMessage() {
		//print message
		System.out.println("Java Program is running");
	}

}