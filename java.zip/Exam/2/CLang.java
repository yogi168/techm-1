public class CLang implements Language, Runnable {

	public void run() {
		showMessage();
	}

	public void showMessage() {
//print message
		System.out.println("C Program is running");
	}

}
