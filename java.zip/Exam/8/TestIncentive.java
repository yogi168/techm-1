import java.util.ArrayList;
import java.util.Scanner;


public class TestIncentive
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		
		
		System.out.println("Enter Employee ID:");
		 int empId=s.nextInt();
		 System.out.println("Enter Employee Name:");
		 String empName=s.next();
		 Employee e = new Employee(empId, empName);
		
		System.out.println("Enter number of flats :");
		int n = s.nextInt();
		for(int i=0;i<n;i++)
		{
		System.out.println("Enter Flat Id:");
		int flatId=s.nextInt();
		System.out.println("Enter Flat Type:");
		 String flatType=s.next();
		 System.out.println("Enter Flat Cost:");
		 double flatCost=s.nextDouble();
		 Flat f = new Flat(flatId);
		 f.setFlatType(flatType);
		 f.setFlatCost(flatCost);
		
			if(f.getFlatCost()!=0 && f.getFlatType()!=null)
			{
			e.addFlat(f);
			e.calculateIncentive(f);
			}
		}
		e.generateReport();
	}

}
