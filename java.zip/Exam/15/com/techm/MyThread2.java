package com.techm;

import java.util.ArrayList;
import java.util.Iterator;

public class MyThread2 extends Thread
{
	ArrayList al;

	public MyThread2(ArrayList al) {
		super();
		this.al = al;
	}
	public synchronized void m1()
	{
	
		Iterator itr=al.iterator();
		while(itr.hasNext())
		{
			Product p=(Product) itr.next();
			
			System.out.println("Product No:"+p.getProdNo()+"\nProduct Name:"+p.getProdName()+"\nProduct Price:"+p.getProdPrice());
			
		}
		
	}
	public void run()
	{
		m1();
	}
	
	
	
}
