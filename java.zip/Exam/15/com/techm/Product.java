package com.techm;

public class Product
{
		int prodNo;	
		String prodName;
		int prodPrice;
		public int getProdNo() {
			return prodNo;
		}
		public void setProdNo(int prodNo) {
			this.prodNo = prodNo;
		}
		public String getProdName() {
			return prodName;
		}
		public void setProdName(String prodName) {
			this.prodName = prodName;
		}
		public int getProdPrice() {
			return prodPrice;
		}
		public void setProdPrice(int prodPrice) {
			this.prodPrice = prodPrice;
		}

		

}
