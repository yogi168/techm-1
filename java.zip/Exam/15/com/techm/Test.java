package com.techm;

import java.util.ArrayList;

public class Test
{
	
	public static void main(String args[])
	{
		
		ArrayList al=new ArrayList();
		
		MyThread1 t1=new MyThread1(al);
		t1.start();
		
		
		MyThread2 t2=new MyThread2(al);
		t2.start();
	
	}
		
}

