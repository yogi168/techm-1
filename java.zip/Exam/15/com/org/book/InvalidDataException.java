package com.org.book;

public class InvalidDataException extends RuntimeException
{
	InvalidDataException(String s)
	{
		super(s);
	}
}