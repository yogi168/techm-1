package mobilee;

import java.util.Scanner;

public class ServiceBill {
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	 System.out.println("enter mobile number");
	 sc.nextLong();
	 System.out.println("enter service id");
	 sc.nextInt();
	 System.out.println("no of units consumed");
	 sc.nextLong();
	 for(int i=0;i<=2;i++){
		 long total;
	 }
}
}
