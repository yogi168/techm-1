package mobile.service;


public class DataService extends Service 
{
public DataService(int serviceID, String serviceName, int monthlyRent,
			int freeUnits) {
		super(serviceID, serviceName, monthlyRent, freeUnits);
		// TODO Auto-generated constructor stub
	}
public String toString()
{
	return serviceID+"....."+serviceName+"...."+monthlyRent+"...."+freeUnits;
	
}
float charge;
double chargableunits ;
public void calculateCharge(int noOfUnits)
{
	if(noOfUnits<freeUnits)
	{
	  charge = 0;	
	}
	else 
	{
		 charge = (float) ((noOfUnits-freeUnits)*0.02);
	}
}
public int getServiceID() {
	// TODO Auto-generated method stub
	return 0;
}
}
