package mobile.service;

public abstract class Service {
int serviceID;
String serviceName;
int monthlyRent;
int freeUnits;
public Service(int serviceID, String serviceName, int monthlyRent, int freeUnits) {
	super();
	this.serviceID = serviceID;
	this.serviceName = serviceName;
	this.monthlyRent = monthlyRent;
	this.freeUnits = freeUnits;
}
public int getServiceID() {
	return serviceID;
}
public String getServiceName() {
	return serviceName;
}
public int getMonthlyRent() {
	return monthlyRent;
}
public int getFreeUnits() {
	return freeUnits;
}
public void setServiceID(int serviceID) {
	this.serviceID = serviceID;
}
public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
}
public void setMonthlyRent(int monthlyRent) {
	this.monthlyRent = monthlyRent;
}
public void setFreeUnits(int freeUnits) {
	this.freeUnits = freeUnits;
}
public abstract void calculateCharge(int noOfUnits);
}
