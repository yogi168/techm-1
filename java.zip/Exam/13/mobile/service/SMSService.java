package mobile.service;

 
public class SMSService extends Service
{
	public SMSService(int serviceID, String serviceName, int monthlyRent,
			int freeUnits) {
		super(serviceID, serviceName, monthlyRent, freeUnits);
		
	}
	public String toString()
	{
		return serviceID+"....."+serviceName+"...."+monthlyRent+"...."+freeUnits;
		
	}
	float charge;
	double chargableunits;
	public void calculateCharge(int noOfUnits)
	{
		if(noOfUnits<=freeUnits)
		{
		 charge = 0;	
		}
		else 
		{
			chargableunits = noOfUnits-freeUnits;
		}
		if(chargableunits<=freeUnits)
		{
			charge=(float) (chargableunits*0.5);
		}
		else
		{
			charge=(float) ((freeUnits*0.5) +((chargableunits-freeUnits)*0.2));
		}
	}
	public int getServiceID() {
		// TODO Auto-generated method stub
		return 0;
	}

}