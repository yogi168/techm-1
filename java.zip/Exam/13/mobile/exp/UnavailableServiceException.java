package mobile.exp;

public class UnavailableServiceException extends  RuntimeException 
{
	
		void MyException(String message)
		{
			System.out.println("not present");
		}
	

}
