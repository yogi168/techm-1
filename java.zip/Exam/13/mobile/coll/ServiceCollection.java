package mobile.coll;

import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.ws.Service;

import mobile.service.DataService;
import mobile.service.SMSService;

public class ServiceCollection
{
	static Service availableServices[]=new Service[5];
	static ArrayList al=new ArrayList();
	static
	{
//	private static  Array availableServices;
	
	/*availableServices[0]= new DataService(1,"3G-1GB",200,100000);
	availableServices[1]= new DataService(2,"3G-2GB",400,200000);
	availableServices[2]= new DataService(3,"2G-1GB",150,100000);
	availableServices[3]= new SMSService(4,"SMS-100",25,100);
	availableServices[4]= new SMSService(5,"SMS-300",60,300);*/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
	al.add(availableServices[0]);
	al.add(availableServices[1]);
	al.add(availableServices[2]);
	al.add(availableServices[3]);
	al.add(availableServices[4]);
	
	}
	public static Object getService(int serviceID)
	{
		Iterator itr = al.iterator();
	
	while(itr.hasNext())
	{
		DataService d = (DataService) itr.next();
		SMSService s = (SMSService) itr.next();
		if((d.getServiceID()==serviceID)||(s.getServiceID()==serviceID))
		{
			System.out.println("The service details are.....");
			System.out.println(d);
			System.out.println(s);
		}
		else
			System.out.println("not found");
	}
	return serviceID ;
		
}
}