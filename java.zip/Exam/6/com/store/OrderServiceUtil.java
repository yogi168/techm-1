package com.store;
import java.util.TreeMap;
import com.store.test.InvalidOrderException;

public class OrderServiceUtil {
	Order order;

	public OrderServiceUtil(Order order) {
		super();
		this.order = order;
	}

	public void addOrder(Order o1) {

		TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
		tm.put(o1.getOrderId(), o1.getCustomerName());
		System.out.println("your order has been added ...");
	}

	public Order searchOrder(int OrderId) {
		System.out.println("your ordered items has been found ..");
		return order;
	}

	public void findTotal() {
		order.setOrderAmount((int) (Math.random() * 100));
		System.out.println("your bill amount is ....");
		System.out.println(order.getOrderAmount());
		if ((order.getOrderAmount() < 100)||
				!((order.getPaymentOption().equals("CoD")||order.getPaymentOption().equals("Gift Card")||order.getPaymentOption().equals("InternetBanking")))){
			try {
				throw new InvalidOrderException("amount should be greater than 100 and enter valid mode");
			} catch (InvalidOrderException e) {
				System.out.println(e);
			}
			
		}

	
	}

		
	
	

	
}
