package com.store.test;

public class InvalidOrderException extends Exception {
	public InvalidOrderException(String s) {
		super(s);

	}
}
