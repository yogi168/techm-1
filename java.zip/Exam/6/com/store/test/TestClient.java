package com.store.test;

import java.util.Scanner;

import com.store.Order;
import com.store.OrderServiceUtil;

public class TestClient {
	public static void main(String[] args) throws InvalidOrderException {

		Scanner sc = new Scanner(System.in);
		int orderId = (int) (Math.random() * 10000);
		System.out.println("please enter your name");
		String customerName = sc.next();
		float orderAmount = 0;
		System.out.println("please enter the type of order");
		String paymentOption = sc.next();

		Order od = new Order(orderId, customerName, orderAmount, paymentOption);

		OrderServiceUtil osc = new OrderServiceUtil(od);
		osc.addOrder(od);
		osc.searchOrder(orderId);
		osc.findTotal();
		sc.close();
	
	}

}
