
public class MediumThread implements Runnable
{
	Thread thread3;
	public MediumThread(Thread thread3) {
		
		this.thread3=thread3;
	}

	public synchronized void m2() throws InterruptedException
	{
		thread3.join();
		for(int i=20;i<=20;i++)
		{
			for(int j=1;j<=10;j++ )
			{
				System.out.println(i+"*"+j +"="+(i*j));
			}
		}
	}
	public void run() {
		
		try {
			m2();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
