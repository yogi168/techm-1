
public class SlowThread implements Runnable
{
	Thread thread2;
	public SlowThread(Thread thread2) {
		
		this.thread2=thread2;
	}
	
	public synchronized void m3() throws InterruptedException
	{
		thread2.join();
		for(int i=10;i<=10;i++)
		{
			for(int j=1;j<=10;j++ )
			{
				System.out.println( i+"*"+j +"="+(i*j));
			}
		}
		
	}

	
	public void run() {
		
		try {
			m3();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
}
