package com.help;

import java.io.File;

public class HelpDesk
{
	
	
		 int requestId;
		 int empId;
		 String problem;
		String status;
		String remarks;
		public HelpDesk(int requestId, int empId, String problem,
				String status, String remarks) {
			super();
			this.requestId = requestId;
			this.empId = empId;
			this.problem = problem;
			this.status = status;
			this.remarks = remarks;
		}
		
	
		
		


	}


