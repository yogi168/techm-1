package com.help;

public class FileNotAvailable extends Exception
{
	FileNotAvailable(String s)
	{
		super(s);
	}
	
}
