package com.techm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


public class MyThread1 extends Thread
{
	ArrayList al;
	
	public MyThread1(ArrayList al) {
		super();
		this.al = al;
	}
	public synchronized void m1()
	{
		Scanner s = new Scanner(System.in);	
		System.out.println("Enter cafe name:");
		String cafename=s.next();
		
				
		Iterator itr = al.iterator();
		while(itr.hasNext())
		{
			CyberCafe cyber=(CyberCafe)itr.next();
			if(cyber.getCafeName().equals(cafename))
			{
				System.out.println("Cyber Cafe name:"+cyber.getCafeName());
				System.out.println("Cyber Cafe Address:"+cyber.getAddress());
				System.out.println("Cyber Cafe members:"+cyber.getMembersCount());
				System.out.println("Cyber Cafe Rate:"+cyber.getRatePerHour());
				break;
			}
			else
			{
				System.out.println("Not in the list");
				break;
			}
		}
	}
	public synchronized void m2()
	{
		Scanner s = new Scanner(System.in);	
		System.out.println("Enter cafe name:");
		String cafename=s.next();
		
				
		Iterator itr = al.iterator();
		while(itr.hasNext())
		{
			CyberCafe cyber=(CyberCafe)itr.next();
			if(cyber.getCafeName().equals(cafename))
			{
				System.out.println("Cyber Cafe name:"+cyber.getCafeName());
				System.out.println("Cyber Cafe Address:"+cyber.getAddress());
				System.out.println("Cyber Cafe members:"+cyber.getMembersCount());
				System.out.println("Cyber Cafe Rate:"+cyber.getRatePerHour());
				break;
			}
			else
			{
				System.out.println("Not in the list");
				break;
			}
		}
	}



	public void run()
	{
		m1();
		m2();
	}

	
}
