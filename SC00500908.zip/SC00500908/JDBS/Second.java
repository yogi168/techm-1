package asignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Second {
	public static void main(String[] args) {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		try {
			Scanner sc = new Scanner(System.in);
			// load and register the driver .
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("driver is loading");
			// Establish the connection
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			System.out.println("connected with the database");

			System.out.println("   \t Employee Management \t ");
			System.out.println("-------------------------------");
			System.out.println("enter the choice  \n"
					+ "  1 . Display All Employees \n"
					+ "	2 .Display First Employee \n"
					+ "  3 . Display Last Employee \n"
					+ "  4 . Display All Departments \n"
					+ "  5 . Display First Department  \n"
					+ "  6 . Display Last Department  \n" + "  7 . Exit");
			int n = sc.nextInt();
			switch (n) {
			case 1:

				// create Statement
				stmt = con.createStatement();
				// execute queries on dba
				rs = stmt.executeQuery("select * from emp2 ");
				System.out.println(" deptno  \t empName  ");
				System.out.println("-----------------------------");
				while (rs.next()) {

					System.out.println(rs.getInt("deptNo") + "\t "
							+ rs.getString("empName"));

				}

				break;

			case 2:
				pst = con.prepareStatement("select  deptno,empName from emp2",
						ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.CONCUR_UPDATABLE);
				rs = pst.executeQuery();

				rs.first();

				System.out.println(rs.getInt("deptno") + "\t "
						+ rs.getString("empName"));
				break;
			case 3:
				pst = con.prepareStatement("select  deptno,empName from emp2",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				rs = pst.executeQuery("select  deptno ,empName from emp2");

				rs.last();

				System.out.println(rs.getInt("deptNo") + "\t "
						+ rs.getString("empName"));
				break;
			case 4:
				pst = con.prepareStatement("select  deptno,empName from emp2",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				rs = pst.executeQuery("select  DISTINCT deptno  from emp2");
				System.out.println(" department");
				System.out.println("-----------------------------");
				while (rs.next()) {

					System.out.println(rs.getInt("deptno"));

				}

				break;
			case 5:
				pst =  con.prepareStatement("select  deptno,empName from emp2",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				rs = pst.executeQuery("");
				rs.first();
				System.out.println(rs.getInt("deptno"));
				break;
			case 6:
				pst = con.prepareStatement("select  deptno,empName from emp2",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				rs = pst.executeQuery("select   deptno  from emp2");
				rs.last();
				System.out.println(rs.getInt("deptno"));
				break;
			case 7:

				break;

			default:
				break;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
