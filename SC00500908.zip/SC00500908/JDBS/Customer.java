package asignment;

import java.sql.Date;

public class Customer {
	int customerId;
	String Name;
	long contactNo;
	String Address;
	Date DateOfBirth;
	public Customer(int customerId, String name, long contactNo,
			String address, Date dateOfBirth) {
		super();
		this.customerId = customerId;
		Name = name;
		this.contactNo = contactNo;
		Address = address;
		DateOfBirth = dateOfBirth;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public Date getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", Name=" + Name
				+ ", contactNo=" + contactNo + ", Address=" + Address
				+ ", DateOfBirth=" + DateOfBirth + "]";
	}

}
