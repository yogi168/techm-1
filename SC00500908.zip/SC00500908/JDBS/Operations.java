package asignment;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Operations {
	Scanner sc = new Scanner(System.in);
	MyDBConnection my = new MyDBConnection();
	Statement stmt = null;
	ResultSet rs = null;
	
	public void toInsert()
	
	{
		my.obtainConnection();
	
	try{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		PreparedStatement ps = my.con.prepareStatement("insert into customer values(?,?,?,?,?)");
		Customer c = new Customer;
		System.out.println("Enter custid");
		c.setCustomerId(sc.nextInt());
		ps.setInt(1,c.getCustomerId() );
		System.out.println("Enter customer name");
		c.setName(sc.next());
		ps.setString(2,c.getName());
		System.out.println("Enter Customer mobile no.");
		c.setContactNo(sc.nextLong());
		ps.setLong(3, c.getContactNo());
		System.out.println("Enter customer address");
		c.setAddress(sc.next());
		ps.setString(4,c.getAddress());
		System.out.println("Enter date");
		String dt = sc.next();
		java.util.Date d = sdf.parse(dt);
		ps.setDate(5, new java.sql.Date(d.getTime()));
		int n=ps.executeUpdate();
		System.out.println("No.Of records inserted is:"+n);
		ps.clearParameters();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		
		
		sc.close();
		my.closeConnection();
	}
	
	}

	public void toUpdate(){
		my.obtainConnection();
		try {
			stmt=my.con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			System.out.println("Enter custId to update mobile num of that customer");
			int n=sc.nextInt();
			System.out.println("Enter mobile num to update");
			long mobile=sc.nextLong();
			int n1 = stmt.executeUpdate("update emp2 set mobile="+mobile+" where custid="+n+"");
			System.out.println("No.Of Rows updated is: "+n1);
			
			//rs.updateRow();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			sc.close();
			my.closeConnection();
		}
		
	}
	
	public void toDelete(){
		my.obtainConnection();
		try {
			stmt=my.con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			System.out.println("Enter custId to delete");
			int n=sc.nextInt();
			
			rs = stmt.executeQuery("select custid,customername,customercontactno,customeraddress,t_date from customer where customerid="+n+"");
			rs.next();
			rs.deleteRow();
			//rs.updateRow();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			sc.close();
			my.closeConnection();
		}
		
	}
	
	
	public void toDisplayAll(){
		my.obtainConnection();
		try {
			stmt=my.con.createStatement();
			rs=stmt.executeQuery("select * from customer");
			while(rs.next()){
				System.out.println(rs.getInt("customerid")+"\t"+rs.getString("customername")+"\t"+rs.getLong("customercontactno")+"\t"+rs.getString("customeraddress")+"\t"+ rs.getDate("t_date"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


		
	}

