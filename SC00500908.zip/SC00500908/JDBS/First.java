package asignment;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class First {
	public static void main(String[] args) {
		ResultSet rs = null;
		Connection con = null;
		Statement stmt = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver is loaded");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			System.out.println("Connected with DataBase");
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			rs = stmt
					.executeQuery("select empid,ename,dname,location from emp1");
			while (rs.next()) {

				System.out.println(rs.getInt(1) + "\t\t" + "\t\t"
						+ rs.getString(2) + "\t\t" + rs.getString(3) + "\t\t"
						+ rs.getString(4));
			}
			System.out.println("First employee");
			rs = stmt.executeQuery("select * from emp1");
			while (rs.next()) {
				if (rs.isFirst()) {
					System.out.println(rs.getInt(1) + "\t\t" + "\t\t"
							+ rs.getString(2) + "\t\t" + rs.getString(3)
							+ "\t\t" + rs.getString(4));
				}
			}
			System.out.println("Last employee");
			rs = stmt.executeQuery("select * from emp1");
			while (rs.next()) {
				if (rs.isLast()) {
					System.out.println(rs.getInt(1) + "\t\t" + "\t\t"
							+ rs.getString(2) + "\t\t" + rs.getString(3)
							+ "\t\t" + rs.getString(4));
				}
			}
			System.out.println("All departments");
			rs = stmt.executeQuery("select Dname from emp1");
			while (rs.next()) {
				System.out.println(rs.getString("Dname"));
			}
			System.out.println("First depratment");
			rs = stmt.executeQuery("select Dname from emp1");
			while (rs.next()) {
				if (rs.isFirst()) {
					System.out.println(rs.getString("Dname"));
				}
			}
			System.out.println("Last depratment");
			rs = stmt.executeQuery("select Dname from emp1");
			while (rs.next()) {
				if (rs.isLast()) {
					System.out.println(rs.getString("Dname"));
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
