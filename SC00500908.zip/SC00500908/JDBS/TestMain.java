package asignment;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Operations o=new Operations();
		System.out.println("Menu");
		System.out.println("1.	Insert new Customer details.\n"
				+ "2.	Update the customer details.\n"
				+ "3.	Delete the customer record.\n"
				+ "4.	Display all customer details.\n"
				+ "5.	Exit.");
		int n=sc.nextInt();
		switch (n) {
		case 1:o.toInsert();
			
			break;
		case 2:o.toUpdate();;
		
		break;
		case 3:o.toDelete();;
		
		break;
		case 4:o.toDisplayAll();;
		

		default:
			break;
		}
		
		sc.close();
	}

}

	