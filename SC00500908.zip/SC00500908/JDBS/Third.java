package asignment;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class Third {
	public static void main(String[] args) {
		Connection con = null;
		CallableStatement cst = null;
		Scanner sc = new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			cst = con.prepareCall("{call proc_empname(?,?)}");
			System.out.println("Enter EMPID");
			cst.setInt(1, sc.nextInt());

			cst.registerOutParameter(2, Types.VARCHAR);
			cst.execute();
			System.out.println("Name of employee is " + cst.getString(2));
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			try {
				cst.close();
				sc.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
	}

}
