
package com.techm;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StoreServlet
 */
public class StoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=null;
		PreparedStatement ps=null;
		
		try {
			//1.Load and register
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			
			//2.Establishing the connection
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			
			
			int n = Integer.parseInt(request.getParameter("ID"));
			String name = request.getParameter("Name");
			String batch_id = request.getParameter("BatchID");
			String joiningDate = request.getParameter("JoiningDate");
			String stream= request.getParameter("Stream");
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date d= sdf.parse(joiningDate);
			ps=con.prepareStatement("insert into Participant values(?,?,?,?,?)");
			ps.setInt(1,n);
			ps.setString(2, name);
			ps.setString(3, batch_id);
			ps.setDate(4, new java.sql.Date(d.getTime()));
			ps.setString(5, stream);
			ps.executeUpdate();
			ps.clearParameters();
			//stmt.executeUpdate("insert into Participant values("+n+",'"+name+"','"+batch_id+"','"+new java.sql.Date(d.getTime())+"'),'"+stream+"'");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{

			try {
				
				ps.close();
				con.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
