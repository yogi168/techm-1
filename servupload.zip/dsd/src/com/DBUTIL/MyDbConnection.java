package com.DBUTIL;
import java.sql.*;
public class MyDbConnection {
	public static Connection obtainConnection()throws Exception{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
		return con;
		
	}
		
	
}
